import { useEffect, useState } from 'react';
import './App.css';

const initialFactData = {
	fact: '',
	length: null,
};
const factsStorageKey = 'cat-facts';
function App() {
	const [fact, setFact] = useState(initialFactData);
	const [factList, setFactList] = useState(
		JSON.parse(localStorage.getItem(factsStorageKey) || null) ?? []
	);

	useEffect(() => {
		fetch('https://catfact.ninja/fact?max_length=80')
			.then((response) => response.json())
			.then((data) => {
				setFact(data);
				const newFactList = [
					...factList,
					{ ...data, date: new Date().toDateString() },
				];
				setFactList(newFactList);
				localStorage.setItem(factsStorageKey, JSON.stringify(newFactList));
			});
	}, []);
	const sortedList = factList.reverse();

	return (
		<div className='App'>
			<div>
				<h1>#CAT FACT</h1>
			</div>
			<h2>{fact.fact}</h2>

			<hr />
			<br />
			<h2>Fact list</h2>
			<ul className='card'>
				{sortedList.map((item) => (
					<li key={item.length}>
						{item.fact} - {item.date}
					</li>
				))}
			</ul>
		</div>
	);
}

export default App;
